package com.example;

import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.sql.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class App {
    public static void main(String[] args) {
        // Initialize Spark Session
        SparkSession spark = SparkSession.builder()
                .appName("WineQualityPrediction")
                .master("local[*]")
                .getOrCreate();

        try {
            // Load test data
            Dataset<Row> testData = spark.read()
                    .option("header", "true")
                    .option("inferSchema", "true")
                    .option("delimiter", ";")
                    .csv("file:/app/dataset/TestDataset.csv");

            // Clean up column names (remove extra quotes)
            testData = cleanColumnNames(testData);

            // Load the saved model
            PipelineModel model = PipelineModel.load("file:/app/models/wine-quality-random-forest-model");

            // Predict on test data
            Dataset<Row> predictions = model.transform(testData);

            // Define evaluator for classification tasks (e.g., F1 score)
            MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
                    .setLabelCol("quality")
                    .setPredictionCol("prediction")
                    .setMetricName("f1"); // Metric can be 'f1', 'accuracy', 'weightedPrecision', etc.

            // Calculate the F1 score on test data
            double metricValue = evaluator.evaluate(predictions);

            // Output the dynamically calculated F1 score to the console
            System.out.println("Prediction Completed. F1 Score on Test Data: " + metricValue);

            // Store the metric value in a text file
            storeMetricToFile("F1 Score", metricValue);

            // Optionally, show some prediction samples for verification
            predictions.select("quality", "prediction", "probability").show(50);

        } catch (Exception e) {
            System.err.println("An error occurred during prediction: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Stop Spark session
            spark.stop();
        }
    }

    /**
     * Cleans column names by removing extra quotes and spaces.
     *
     * @param dataset Dataset with original column names
     * @return Dataset with cleaned column names
     */
    private static Dataset<Row> cleanColumnNames(Dataset<Row> dataset) {
        for (String column : dataset.columns()) {
            String cleanedColumn = column.replaceAll("\"", "").trim();
            dataset = dataset.withColumnRenamed(column, cleanedColumn);
        }
        return dataset;
    }

    /**
     * Stores the evaluation metric value in a text file.
     *
     * @param metricName  Name of the metric (e.g., F1 Score, Accuracy)
     * @param metricValue Metric value to be stored in the file
     */
    private static void storeMetricToFile(String metricName, double metricValue) {
        try {
            // Specify the file path
            File file = new File("/app/metrics.txt");

            // Create a FileWriter to write to the file
            FileWriter writer = new FileWriter(file, true); // 'true' to append to the file
            writer.write(metricName + ": " + metricValue + "\n"); // Write the metric to the file
            writer.close(); // Close the writer

            System.out.println(metricName + " saved to file: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error writing metric to file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
