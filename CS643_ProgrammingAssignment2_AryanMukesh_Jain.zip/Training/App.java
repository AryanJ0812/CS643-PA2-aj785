package com.example;

import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.classification.RandomForestClassifier;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.StandardScaler;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.tuning.CrossValidator;
import org.apache.spark.ml.tuning.ParamGridBuilder;
import org.apache.spark.sql.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import scala.collection.JavaConverters;
import scala.collection.Seq;

public class App {
    public static void main(String[] args) {
        int numTrees = 100;
        int maxDepth = 6;
        int minInstancesPerNode = 4;
        double subsamplingRate = 1.0;
        int NumFolds = 10;

        // Initialize Spark Session
        SparkSession spark = SparkSession.builder()
                .appName("WineQualityModelTraining")
                .getOrCreate();

        // Load training data
        Dataset<Row> trainingData = spark.read()
                .option("header", "true")
                .option("inferSchema", "true")
                .option("delimiter", ";")
                .csv("file:///home/ubuntu/datasets/TrainingDataset.csv");

        // Load validation data
        Dataset<Row> validationData = spark.read()
                .option("header", "true")
                .option("inferSchema", "true")
                .option("delimiter", ";")
                .csv("file:///home/ubuntu/datasets/ValidationDataset.csv");

        // Clean up column names (remove extra quotes)
        trainingData = cleanColumnNames(trainingData);
        validationData = cleanColumnNames(validationData);

        // Assemble features
        VectorAssembler assembler = new VectorAssembler()
                .setInputCols(new String[] { "volatile acidity", "citric acid",
                        "residual sugar", "chlorides", "free sulfur dioxide",
                        "total sulfur dioxide", "density", "sulphates", "alcohol" })
                .setOutputCol("rawFeatures");

        // Scale features for better model performance
        StandardScaler scaler = new StandardScaler()
                .setInputCol("rawFeatures")
                .setOutputCol("features")
                .setWithStd(true)
                .setWithMean(false);

        // Define Random Forest Classifier
        RandomForestClassifier rf = new RandomForestClassifier()
                .setLabelCol("quality")
                .setFeaturesCol("features");

        // Create parameter grid for hyperparameter tuning
        ParamGridBuilder paramGridBuilder = new ParamGridBuilder()
                .addGrid(rf.numTrees(), new int[] { numTrees }) // Optimized number of trees
                .addGrid(rf.maxDepth(), new int[] { maxDepth }) // Increased maximum depth
                .addGrid(rf.minInstancesPerNode(), new int[] { minInstancesPerNode }) // Fine-tune node size
                .addGrid(rf.subsamplingRate(), new double[] { subsamplingRate }) // Subsample training data
                .addGrid(
                        rf.featureSubsetStrategy(),
                        JavaConverters.asScalaBufferConverter(
                                java.util.Arrays.asList("auto")).asScala());

        // Define evaluator for model evaluation
        MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
                .setLabelCol("quality")
                .setPredictionCol("prediction")
                .setMetricName("f1");

        // Set up Cross-Validation with Random Forest
        CrossValidator cv = new CrossValidator()
                .setEstimator(rf)
                .setEvaluator(evaluator)
                .setEstimatorParamMaps(paramGridBuilder.build()) // Use build() to get the ParamMap array
                .setNumFolds(NumFolds); // Use 10-fold cross-validation

        // Create a pipeline to apply the stages
        Pipeline pipeline = new Pipeline().setStages(new org.apache.spark.ml.PipelineStage[] { assembler, scaler, cv });

        // Fit the model using training data
        PipelineModel model = pipeline.fit(trainingData);

        // Evaluate on validation data
        Dataset<Row> validationTransformed = model.transform(validationData);
        double f1Score = evaluator.evaluate(validationTransformed);

        System.out.println("Model Training Completed. F1 Score on Validation Data: " + f1Score + "Values: " + numTrees
                + maxDepth + minInstancesPerNode);

        // Save the trained model
        try {
            model.write().overwrite().save("file:///home/ubuntu/models/wine-quality-random-forest-model");
            System.out
                    .println("Model saved successfully to file:///home/ubuntu/models/wine-quality-random-forest-model");
        } catch (IOException e) {
            System.err.println("Failed to save the model: " + e.getMessage());
            e.printStackTrace();
        }

        // Store the F1 score in a text file
        storeF1ScoreToFile(f1Score, numTrees, maxDepth, minInstancesPerNode, subsamplingRate, NumFolds);

        // Stop Spark session
        spark.stop();
    }

    /**
     * Cleans column names by removing extra quotes and spaces.
     *
     * @param dataset Dataset with original column names
     * @return Dataset with cleaned column names
     */
    private static Dataset<Row> cleanColumnNames(Dataset<Row> dataset) {
        for (String column : dataset.columns()) {
            String cleanedColumn = column.replaceAll("\"", "").trim();
            dataset = dataset.withColumnRenamed(column, cleanedColumn);
        }
        return dataset;
    }

    /**
     * Stores the F1 score in a text file.
     *
     * @param f1Score F1 score to be stored in the file
     */
    private static void storeF1ScoreToFile(double f1Score, int numTrees, int maxDepth, int minInstancesPerNode,
            double subsamplingRate, int NumFolds) {
        try {
            // Specify the file path
            File file = new File("/home/ubuntu/f1_score.txt");

            // Create a FileWriter to write to the file
            FileWriter writer = new FileWriter(file, true); // 'true' to append to the file
            writer.write("F1 Score: " + f1Score + "\n"); // Write the F1 score to the file
            writer.close(); // Close the writer

            System.out.println("F1 Score saved to file: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error writing F1 score to file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
